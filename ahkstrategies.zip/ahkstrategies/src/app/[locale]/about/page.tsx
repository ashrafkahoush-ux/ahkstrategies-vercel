import AboutSection from '../../../components/AboutSection';

export const metadata = {
  title: 'About Us'
};

export default function AboutPage() {
  return (
    <AboutSection />
  );
}