"use client";

import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { useLocale, useTranslations } from 'next-intl';
import LanguageToggle from './LanguageToggle';

export default function Navbar() {
  const t = useTranslations('Nav');
  const locale = useLocale();
  const pathname = usePathname();
  // Build path without the locale prefix so the toggle can preserve the route
  const pathWithoutLocale = pathname.replace(/^\/(en|ar)/, '');
  return (
    <header className="bg-primary text-white shadow">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Brand with logo and name */}
        <Link href={`/${locale}`} className="flex items-center space-x-2">
          {/* Display the logo image from the public/images directory */}
          <Image src="/images/logo.png" alt="AHKStrategies logo" width={40} height={40} />
          <span className="text-xl font-semibold">AHKStrategies</span>
        </Link>
        <nav className="space-x-4 flex items-center">
          <Link href={`/${locale}/`} className="hover:underline">
            {t('home')}
          </Link>
          <Link href={`/${locale}/about`} className="hover:underline">
            {t('about')}
          </Link>
          <Link href={`/${locale}/services`} className="hover:underline">
            {t('services')}
          </Link>
          <Link href={`/${locale}/contact`} className="hover:underline">
            {t('contact')}
          </Link>
          <LanguageToggle currentPath={pathWithoutLocale} />
        </nav>
      </div>
    </header>
  );
}