exports.id=467,exports.ids=[467],exports.modules={2113:(t,e,s)=>{let{createProxy:a}=s(6843);t.exports=a("C:\\Users\\skaho\\Downloads\\ahkstrategies\\ahkstrategies\\node_modules\\next\\dist\\client\\script.js")},4825:(t,e,s)=>{t.exports=s(2113)},7467:(t,e,s)=>{"use strict";s.r(e),s.d(e,{default:()=>i});var a=s(5036),r=s(4825),n=s.n(r);function i(){let t=process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN,e=process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID;return(0,a.jsxs)(a.Fragment,{children:[t&&a.jsx(n(),{src:"https://plausible.io/js/script.js","data-domain":t,strategy:"afterInteractive"}),e&&(0,a.jsxs)(a.Fragment,{children:[a.jsx(n(),{src:`https://www.googletagmanager.com/gtag/js?id=${e}`,strategy:"afterInteractive"}),a.jsx(n(),{id:"ga-init",strategy:"afterInteractive",children:`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${e}');
            `})]})]})}}};