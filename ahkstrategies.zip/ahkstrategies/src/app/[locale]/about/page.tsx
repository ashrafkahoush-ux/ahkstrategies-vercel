import AboutSection from '../../../components/AboutSection';
import FounderSection from '../../../components/FounderSection';

export const metadata = {
  title: 'About Us'
};

export default function AboutPage() {
  return (
    <>
      <AboutSection />
      <FounderSection />
    </>
  );
}