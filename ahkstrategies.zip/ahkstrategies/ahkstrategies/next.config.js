/** @type {import('next').NextConfig} */
const nextConfig = {
  // other config if needed
};

module.exports = nextConfig;
