import ServicesSection from '../../../components/ServicesSection';

export const metadata = {
  title: 'Our Services'
};

export default function ServicesPage() {
  return <ServicesSection />;
}