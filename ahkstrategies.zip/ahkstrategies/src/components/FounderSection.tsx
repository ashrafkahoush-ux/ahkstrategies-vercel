import Image from 'next/image';
import { useTranslations } from 'next-intl';

/**
 * Renders a rich founder section with portrait, biography and contact links.
 * All copy is pulled from the i18n messages under the `Founder` namespace.
 */
export default function FounderSection() {
  const t = useTranslations('Founder');
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 max-w-5xl flex flex-col md:flex-row items-center gap-10">
        {/* Portrait */}
        <div className="md:w-5/12 w-full flex justify-center">
          <Image
            src="/images/founder.png"
            alt={t('subtitle')}
            width={640}
            height={800}
            className="rounded-lg shadow-lg object-cover"
            priority
          />
        </div>
        {/* Content */}
        <div className="md:w-7/12 w-full">
          <h2 className="text-3xl font-semibold mb-4 text-primary">
            {t('heading')}
          </h2>
          <h3 className="text-xl font-medium mb-4 text-gray-800">
            {t('subtitle')}
          </h3>
          <p className="text-gray-700 leading-relaxed mb-6">
            {t('bio')}
          </p>
          <div className="space-y-2 text-gray-700">
            <p>
              <strong>Email:</strong>{' '}
              <a href={`mailto:${t('contact.email1')}`} className="text-primary underline">
                {t('contact.email1')}
              </a>{' '}
              /{' '}
              <a href={`mailto:${t('contact.email2')}`} className="text-primary underline">
                {t('contact.email2')}
              </a>
            </p>
            <p>
              <strong>Mobile:</strong>{' '}
              <a href={`tel:${t('contact.phone')}`} className="text-primary underline">
                {t('contact.phone')}
              </a>
            </p>
            <p>
              <strong>LinkedIn:</strong>{' '}
              <a
                href={`https://${t('contact.linkedin')}`}
                className="text-primary underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                {t('contact.linkedin')}
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}