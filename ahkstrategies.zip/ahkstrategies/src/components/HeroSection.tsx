import Link from 'next/link';
import Image from 'next/image';
import { useTranslations, useLocale } from 'next-intl';

export default function HeroSection() {
  const t = useTranslations('Hero');
  const locale = useLocale();
  return (
    <section className="relative py-28 sm:py-32 overflow-hidden">
      {/* Background image and overlay */}
      <Image
        src="/images/banner.jpg"
        alt="AHKStrategies network graphic"
        fill
        className="object-cover object-center opacity-40"
        priority
      />
      <div className="absolute inset-0 bg-black/40"></div>
      <div className="relative z-10 container mx-auto px-4 text-center max-w-3xl">
        <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-white drop-shadow-lg">
          {t('title')}
        </h1>
        <p className="text-lg sm:text-xl mb-8 text-white/90">
          {t('subtitle')}
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            href={`/${locale}/contact#lead-form`}
            className="bg-primary text-white px-6 py-3 rounded hover:bg-primary-dark transition shadow-md"
          >
            {t('ctaLead')}
          </Link>
          <Link
            href={`/${locale}/contact#partner-form`}
            className="bg-accent text-white px-6 py-3 rounded hover:bg-accent-dark transition shadow-md"
          >
            {t('ctaPartner')}
          </Link>
        </div>
      </div>
    </section>
  );
}